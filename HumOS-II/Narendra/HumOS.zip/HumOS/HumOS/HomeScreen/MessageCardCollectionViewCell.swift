//
//  MessageCardCollectionViewCell.swift
//  HumOS
//
//  Created by Deepesh.Sunku on 9/2/16.
//  Copyright © 2016 Sikka Software. All rights reserved.
//

import UIKit

class MessageCardCollectionViewCell: UICollectionViewCell {
    
}
